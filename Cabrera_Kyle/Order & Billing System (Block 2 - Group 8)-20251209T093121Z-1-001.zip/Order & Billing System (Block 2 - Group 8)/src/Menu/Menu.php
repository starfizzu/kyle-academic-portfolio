<?php

namespace Cafe\Menu;

use Cafe\Items\CafeFood;

class Menu {
  
    public function getItems(): array
    {
        return [
            1 => new CafeFood('Matcha Latte', 110.00),
            2 => new CafeFood('Graham Latte', 120.00),
            3 => new CafeFood('White mocha', 100.00),
            4 => new CafeFood('Blueberry Soda', 110.00),
            5 => new CafeFood('Cotton Candy Soda', 100.00),
            6 => new CafeFood('Tiramisu', 130.00),
            7 => new CafeFood('Nachos', 70.00),
            8 => new CafeFood('Fries', 80.00),
        ];
    }

    public function displayLine(string $name) {
        $line = "-------------------------------------------";
        $items = $this->getItems();
        
        $text = "\nNice to meet you, " . $name . "! \nHere's our menu today:\n\n";
        
        $text .= "Coffee Drinks: \n";
        $text .= "[1] " . $items[1] . " (Customer Favorite!)\n";
        $text .= "[2] " . $items[2] . "\n";
        $text .= "[3] " . $items[3] . "\n\n";
        
        $text .= "Non-Coffee: \n";
        $text .= "[4] " . $items[4] . "\n";
        $text .= "[5] " . $items[5] . "\n\n";
        
        $text .= "Snacks: \n";
        $text .= "[6] " . $items[6] . " (Customer Favorite!)\n";
        $text .= "[7] " . $items[7] . "\n";
        $text .= "[8] " . $items[8] . "\n\n";
        
        $text .= $line . "\n";
        $text .= "Enter the number of the item you'd like to order.\n";
        $text .= "Type 0 anytime to finish ordering.\n";
        $text .= "One item per order.\n";
        $text .= $line;
        
        return $text;
    }
}
