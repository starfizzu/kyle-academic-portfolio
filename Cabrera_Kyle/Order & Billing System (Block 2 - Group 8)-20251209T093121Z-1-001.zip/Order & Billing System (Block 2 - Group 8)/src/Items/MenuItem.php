<?php

namespace Cafe\Items;

abstract class MenuItem implements Priced {

    protected $name;
    protected $price;
    
   
    public function __construct(string $name, float $price)
    {
        $this->name = $name;
        $this->price = $price;
    }

  
    public function getName(): string
    {
        return $this->name;
    }


    public function getPrice(): float
    {
        return $this->price;
    }


    public function __toString(): string
    {
        return $this->name . ' - ₱' . number_format($this->price, 2);
    }
}