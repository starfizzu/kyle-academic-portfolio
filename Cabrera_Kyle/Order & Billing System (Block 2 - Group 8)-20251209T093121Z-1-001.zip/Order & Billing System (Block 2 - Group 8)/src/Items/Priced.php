<?php

namespace Cafe\Items;

interface Priced {
   
    public function getPrice(): float;
}