<?php

namespace Cafe\Items;

class CafeFood extends MenuItem {
    public function __construct(string $name, float $price)
    {
        parent::__construct($name, $price);
    }
}
