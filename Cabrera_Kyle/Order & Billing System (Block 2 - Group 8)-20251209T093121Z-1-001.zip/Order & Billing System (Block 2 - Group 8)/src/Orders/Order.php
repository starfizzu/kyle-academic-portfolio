<?php

namespace Cafe\Orders;

use Cafe\Items\CafeFood;


class Order {
 
    private string $customerName = '';
    private array $orderItems = [];

    
    public function setCustomerName($name) {
        $this->customerName = $name;
    }


    public function getCustomerName() {
        return $this->customerName;
    }


    public function add($cafeFood, int $quantity = 1) {
        foreach ($this->orderItems as $orderItem) {
            if ($orderItem->getItem()->getName() === $cafeFood->getName()) {
                $orderItem->setQuantity($orderItem->getQuantity() + $quantity);
                return;
            }
        }
        
        $this->orderItems[] = new QuantityItem($cafeFood, $quantity);
    }


    public function __get(string $name) {
        if ($name === 'total') {
            return $this->calculateTotal();
        }
        return null;
    }
    

    private function calculateTotal() {
        $total = 0.0;
        foreach ($this->orderItems as $item) {
            $total += $item->getSubtotal();
        }
        return $total;
    }

    public function getOrderItems() {
        return $this->orderItems;
    }

 
    public function __clone() {
        $clonedItems = [];
        foreach ($this->orderItems as $item) {
            $clonedItems[] = clone $item;
        }
        $this->orderItems = $clonedItems;
    }

    public function __toString(){
        $output = "Order Summary for " . $this->getCustomerName() . "\n";
        foreach ($this->orderItems as $item) {
            $output .= " - " . $item->getItem()->getName() . " x" . $item->getQuantity() . " = ₱" . number_format($item->getSubtotal(), 2, '.', '') . "\n";
        }
        $output .= "Total: ₱" . number_format($this->total, 2, '.', '') . "\n";
        return $output;
    }

    // View Order method
    public function viewOrder() {
        if (empty($this->orderItems)) {
            return "Your order is currently empty";
        }
        $output = "Current Order Details:\n"; // changed header
        foreach ($this->orderItems as $item) {
            $output .= " - " . $item->getItem()->getName() . " x" . $item->getQuantity() . " = ₱" . number_format($item->getSubtotal(), 2, '.', '') . "\n";
        }
        $output .= "Total: ₱" . number_format($this->total, 2, '.', '') . "\n";
        return $output;
    }

    // Remove item method
    public function remove($itemName) {
        foreach ($this->orderItems as $itemNum => $item) {
            if (strtolower($item->getItem()->getName()) === strtolower($itemName)) {
                unset($this->orderItems[$itemNum]);
                $this->orderItems = array_values($this->orderItems);
                return "Item '{$itemName}' has been successfully removed.";
            }
        }
        return "Item '{$itemName}' not found in your order.";
    }

    // Edit quantity method
    public function edit($itemName, $newQuantity) {
        foreach ($this->orderItems as $item) {
            if (strtolower($item->getItem()->getName()) === strtolower($itemName)) {
                if ($newQuantity <= 0) {
                    $this->remove($itemName);
                    return "Item '{$itemName}' has been removed successfully.";
                } else {
                    $item->setQuantity($newQuantity);
                    return "Item quantity of '{$itemName}' has been successfully updated.";
                }
            }
        }
        return "Item '{$itemName}' not found in your order.";
    }
}
