<?php

namespace Cafe\Orders;

use Cafe\Items\MenuItem;

class QuantityItem {
    private MenuItem $item;
    private int $quantity;

    public function __construct(MenuItem $item, int $quantity = 1) {
        $this->item = $item;
        $this->setQuantity($quantity);
    }


    public function getItem() {
        return $this->item;
    }

    public function getQuantity() {
        return $this->quantity;
    }


    public function setQuantity(int $quantity) {
        if ($quantity <= 0) {
            throw new \InvalidArgumentException('Quantity must be positive');
        }
        $this->quantity = $quantity;
    }

    public function getSubtotal() {
        return $this->item->getPrice() * $this->quantity;
    }

public function __toString() {
    return "{$this->item->getName()} x{$this->quantity} - ₱" . number_format($this->getSubtotal(), 2);
  }
}
