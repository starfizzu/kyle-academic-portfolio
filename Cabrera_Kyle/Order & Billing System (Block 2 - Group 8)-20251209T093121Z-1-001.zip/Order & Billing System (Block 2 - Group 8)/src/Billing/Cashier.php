<?php

namespace Cafe\Billing;

use Cafe\Exceptions\InsufficientPaymentException;
use Cafe\Orders\Order;

class Cashier
{
   
    public function processPayment(Order $order, float $payment): float
    {
        if ($payment <= 0) {
            throw new \InvalidArgumentException('Payment amount must be positive');
        }
        
        $total = $order->total; // Uses the magic __get('total') from Order
        $difference = $payment - $total;

        if ($difference < 0) {
            throw new InsufficientPaymentException(
                sprintf(
                    'Insufficient payment. Amount due: ₱%.2f, Amount paid: ₱%.2f',
                    $total,
                    $payment
                )
            );
        }

        return $difference;
    }
}