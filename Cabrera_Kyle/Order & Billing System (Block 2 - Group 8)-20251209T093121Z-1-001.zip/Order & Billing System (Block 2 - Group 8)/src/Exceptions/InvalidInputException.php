<?php
namespace Cafe\Exceptions;

use Exception;

class InvalidInputException extends Exception {
}