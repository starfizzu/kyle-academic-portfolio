<?php 
namespace Cafe\Exceptions;

use Exception;

class InsufficientPaymentException extends Exception {
    
}