<?php
// Require Composer's autoloader
require __DIR__ . '/vendor/autoload.php';

use Cafe\Menu\Menu;
use Cafe\Orders\Order;
use Cafe\Billing\Cashier;
use Cafe\Exceptions\InsufficientPaymentException;
use Cafe\Exceptions\InvalidInputException;

function read_input($message, $type = 'any') {
    while (true) {
        echo $message;
        $input = trim(fgets(STDIN));

        try {
            if ($input === '') {
                throw new InvalidInputException('Input cannot be empty!');
            }

            switch ($type) {
                case 'number':
                    if (!is_numeric($input)) {
                        throw new InvalidInputException('Invalid input! Enter a number only.');
                    }
                    break;

                case 'menu_choice':
                    if (!ctype_digit($input)) {
                        throw new InvalidInputException('Invalid input! Enter a number only.');
                    }
                    $num = (int)$input;
                    if ($num < 1 || $num > 8) {
                        throw new InvalidInputException('Invalid input! Enter a menu item number between 1–8.');
                    }
                    break;

                case 'action_choice':
                    if (!ctype_digit($input)) {
                        throw new InvalidInputException('Invalid input! Enter a number only.');
                    }

                    $num = (int)$input;
                    if ($num < 0 || $num > 4) {
                        throw new InvalidInputException('Invalid input! Enter an action number between 0-4.');
                    }
                    break;

                default:
                    // allow any input
                    break;
            }

            return $input;

        } catch (InvalidInputException $e) {
            echo $e->getMessage() . "\n";
        }
    }
}

function peso($amount) {
    return '₱' . number_format($amount, 2, '.', '');
}

$menuline = "===========================================";
echo $menuline . "\n";
echo "     WELCOME TO OUR MINI CAFÉ \n";
echo $menuline . "\n\n";

$name = read_input('Hi there! May I know your name? ');
echo "Name: {$name}\n";

$menu = new Menu();

$order = new Order();
$order->setCustomerName($name);

$items = $menu->getItems();
$previousOrder = null;

do {
    if ($previousOrder) {
        $reorder = strtolower(trim(read_input("\nDo you want to reorder your previous order? (y/n): ")));
        if  ($reorder === 'y') {
            $order = clone $previousOrder;
            echo "\nYour previous order has been cloned:\n";
            echo $order;
        } else {
            $order = new Order();
            $order->setCustomerName($name);
        }
    } else {
        $order = new Order();
        $order->setCustomerName($name);
    }

    echo $menu->displayLine($name) . "\n\n";

    while (true) {
        echo "\nActions: \n| 1-Order Item | 2-View Order | 3-Edit Quantity | 4-Remove Item | 0-Checkout |\n";
        $action = read_input('Choose an action: ', 'action_choice');

        if ($action === '0') {
            break;
        }

        switch ((int)$action) {
            case 1:
                $itemNumber = read_input('What would you like to order? (1-8): ', 'menu_choice');
                $num = (int)$itemNumber;
                $item = $items[$num];

                $itemName = $item->getName();
                $foodQuantity = read_input("How many '{$itemName}' would you like? ", 'number');
                $quantity = (int)$foodQuantity;

                if ($quantity <= 0) {
                    echo "\nError: Please enter a valid number greater than 0.\n\n";
                    continue 2;
                }

                $order->add($item, $quantity);
                echo "Added {$itemName} x{$quantity} to your order.\n\n";
                echo "\nCurrent Order:\n";
                echo $order . "\n";
                break;

            case 2:
                echo "\nCurrent Order Details:\n";
                echo $order . "\n";
                break;

            case 3:
                $itemsList = $order->getOrderItems();
                if (empty($itemsList)) {
                    echo "\nNo items to edit.\n";
                    break;
                }

                echo "\nEditing order quantities:\n";
                foreach ($itemsList as $i => $oi) {
                    echo ($i + 1) . ". " . $oi->getItem()->getName() . " x" . $oi->getQuantity() . "\n";
                }

                $editIndex = read_input("\n" . 'Enter item number to edit: ', 'number') - 1;
                if (!isset($itemsList[$editIndex])) {
                    echo "Invalid selection. Please enter a valid item number to edit.\n";
                    continue 2;
                }

                $itemName = $itemsList[$editIndex]->getItem()->getName();
                $newQty = read_input("Enter new quantity for '{$itemName}': ", 'number');

                $order->edit($itemName, (int)$newQty);

                echo "Item quantity of '{$itemName}' has been successfully updated.\n";
                echo "\nUpdated order details:\n";
                echo $order . "\n";
                break;

            case 4:
                $itemsList = $order->getOrderItems();
                if (empty($itemsList)) {
                    echo "\nNo items to remove.\n";
                    break;
                }

                echo "\nRemoving an item:\n";
                foreach ($itemsList as $i => $oi) {
                    echo ($i + 1) . ". " . $oi->getItem()->getName() . " x" . $oi->getQuantity() . "\n";
                }

                $removeIndex = read_input("\n" . 'Enter item number to remove: ', 'number') - 1;
                if (!isset($itemsList[$removeIndex])) {
                    echo "Invalid selection. Please enter a valid item number to remove.\n";
                    continue 2;
                }

                $itemName = $itemsList[$removeIndex]->getItem()->getName();
                $order->remove($itemName);

                echo "Item '{$itemName}' has been successfully removed from your order.\n";
                echo "\nUpdated order details:\n";
                echo $order . "\n";
                break;

            default:
                echo "Invalid action.\n";
                continue 2;
        }
    }

    $totalCheck = $order->total;
    if ($totalCheck <= 0) {
        echo "\nThank You for visiting!\n\n";
        exit;
    }

    echo "\nCurrent Order Details:\n";
    echo $order . "\n";

    $cashier = new Cashier();

    while (true) {
        $userpayment = read_input('Enter payment amount: ', 'number');
        $payment = (float)$userpayment;

        if ($payment <= 0) { 
            echo "Please enter a valid payment!\n";
            continue; 
        }

        try {
            $change = $cashier->processPayment($order, $payment);

            echo "\n========== RECEIPT =========\n";
            echo $order;
            echo "Payment: " . peso($payment) . "\n";
            echo "Change:  " . peso($change) . "\n";
            echo "=============================\n\n";
            echo "Thank You for ordering!\nCome Back Soon!\n";
            break;

        } catch (InsufficientPaymentException $e) {
            echo "Payment is not enough. Please pay your Order Bills! \n";
            continue;
        }
    }

    $previousOrder = $order;

    do {
        $orderAgain = strtolower(trim(read_input("\nDo you want to place another order? (y/n): ")));
        if (!in_array($orderAgain, ['y', 'n'])) {
            echo "Invalid input! Please enter 'y' or 'n'.\n";
        }
    } while (!in_array($orderAgain, ['y', 'n']));

} while ($orderAgain === 'y');

echo "\nThank you for visiting our Mini Café, {$name}! Have a great day!\n";
