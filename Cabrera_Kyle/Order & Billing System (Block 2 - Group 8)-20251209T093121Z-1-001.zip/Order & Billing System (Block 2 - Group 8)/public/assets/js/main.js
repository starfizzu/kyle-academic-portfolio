// Main JavaScript for the Cafe Order System
document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart from localStorage or create empty cart
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Initialize quantity selectors
    document.querySelectorAll('.quantity-selector').forEach(selector => {
        setupQuantitySelector(selector);
    });
    
    // Initialize add to cart buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', addToCart);
    });
    
    // Initialize cart functionality if on cart page
    if (document.querySelector('.cart-items')) {
        updateCartDisplay();
        setupCartEventListeners();
    }
});

/**
 * Setup quantity selector buttons
 */
function setupQuantitySelector(container) {
    const input = container.querySelector('input');
    const minusBtn = container.querySelector('.minus');
    const plusBtn = container.querySelector('.plus');
    
    if (minusBtn) {
        minusBtn.addEventListener('click', () => {
            if (input.value > 1) {
                input.value--;
            }
        });
    }
    
    if (plusBtn) {
        plusBtn.addEventListener('click', () => {
            input.value++;
        });
    }
}

/**
 * Add item to cart
 */
function addToCart(event) {
    const button = event.target.closest('button');
    const itemCard = button.closest('.menu-item');
    
    const item = {
        id: itemCard.dataset.id,
        name: itemCard.querySelector('h3').textContent,
        price: parseFloat(itemCard.querySelector('.price').textContent.replace('$', '')),
        quantity: parseInt(itemCard.querySelector('.quantity-selector input').value) || 1
    };

    updateCart(item);
    updateCartUI();
}

/**
 * Update cart with new item
 */
function updateCart(item) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingItemIndex = cart.findIndex(cartItem => cartItem.id === item.id);
    
    if (existingItemIndex > -1) {
        cart[existingItemIndex].quantity += item.quantity;
    } else {
        cart.push(item);
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
}

/**
 * Update cart UI
 */
function updateCartUI() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartCount = document.getElementById('cart-count');
    
    if (cartCount) {
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartCount.textContent = totalItems;
        cartCount.style.display = totalItems > 0 ? 'inline-block' : 'none';
    }
}

/**
 * Setup cart event listeners
 */
function setupCartEventListeners() {
    document.querySelectorAll('.update-quantity').forEach(input => {
        input.addEventListener('change', updateCartItem);
    });
    
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', removeCartItem);
    });
}

/**
 * Update cart item quantity
 */
function updateCartItem(event) {
    const input = event.target;
    const itemId = input.dataset.id;
    const newQuantity = parseInt(input.value) || 1;
    
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const item = cart.find(item => item.id === itemId);
    
    if (item) {
        item.quantity = newQuantity;
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartDisplay();
    }
}

/**
 * Remove item from cart
 */
function removeCartItem(event) {
    const button = event.target.closest('button');
    const itemId = button.dataset.id;
    
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart = cart.filter(item => item.id !== itemId);
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
}

/**
 * Update cart display
 */
function updateCartDisplay() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartItemsContainer = document.querySelector('.cart-items');
    
    if (!cartItemsContainer) return;
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p>Your cart is empty</p>';
        return;
    }
    
    // Update cart items list
    cartItemsContainer.innerHTML = cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
            <div class="item-details">
                <h4>${item.name}</h4>
                <p>$${item.price.toFixed(2)} each</p>
            </div>
            <div class="item-quantity">
                <input type="number" class="update-quantity" 
                       data-id="${item.id}" 
                       value="${item.quantity}" min="1">
            </div>
            <button class="remove-item" data-id="${item.id}">Remove</button>
        </div>
    `).join('');
    
    // Update total
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    document.querySelector('.cart-total').textContent = `$${total.toFixed(2)}`;
    
    // Re-attach event listeners
    setupCartEventListeners();
    
    // Check if item already in cart
    const existingItemIndex = cart.findIndex(cartItem => cartItem.id === item.id);
    
    if (existingItemIndex > -1) {
        // Update quantity if item exists
        cart[existingItemIndex].quantity += item.quantity;
        showNotification(`Updated ${item.name} in cart`);
    } else {
        // Add new item to cart
        cart.push(item);
        showNotification(`${item.name} added to cart`);
    }
    
    // Save to localStorage
    saveCart();
    
    // Update cart count in header
    updateCartCount();
}

function removeFromCart(itemId) {
    cart = cart.filter(item => item.id !== itemId);
    saveCart();
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartItemsContainer = document.querySelector('.cart-items');
    if (!cartItemsContainer) return;
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
        updateCartSummary();
        return;
    }
    
    let cartHTML = '';
    
    cart.forEach(item => {
        cartHTML += `
            <div class="cart-item" data-id="${item.id}">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-details">
                    <h4>${item.name}</h4>
                    <p>$${item.price.toFixed(2)} x ${item.quantity}</p>
                    <p class="item-total">$${(item.price * item.quantity).toFixed(2)}</p>
                </div>
                <button class="btn btn-remove" data-id="${item.id}">Remove</button>
            </div>
        `;
    });
    
    cartItemsContainer.innerHTML = cartHTML;
    updateCartSummary();
}

function updateCartSummary() {
    const cartSummary = document.querySelector('.cart-summary');
    if (!cartSummary) return;
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.1; // 10% tax
    const total = subtotal + tax;
    
    cartSummary.innerHTML = `
        <h3>Order Summary</h3>
        <div class="summary-row">
            <span>Subtotal:</span>
            <span>$${subtotal.toFixed(2)}</span>
        </div>
        <div class="summary-row">
            <span>Tax (10%):</span>
            <span>$${tax.toFixed(2)}</span>
        </div>
        <div class="summary-row total">
            <strong>Total:</strong>
            <strong>$${total.toFixed(2)}</strong>
        </div>
        <a href="checkout.php" class="btn btn-accent btn-block">Proceed to Checkout</a>
    `;
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
}

function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = totalItems;
        cartCount.style.display = totalItems > 0 ? 'inline-block' : 'none';
    }
}

// Form Validation
function validateCheckoutForm(event) {
    event.preventDefault();
    
    const form = event.target;
    let isValid = true;
    const errors = [];
    
    // Reset previous errors
    document.querySelectorAll('.error-message').forEach(el => el.remove());
    document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    
    // Required fields validation
    const requiredFields = ['name', 'email', 'phone', 'address', 'payment_method'];
    
    requiredFields.forEach(field => {
        const input = form.querySelector(`[name="${field}"]`);
        if (input && !input.value.trim()) {
            showFieldError(input, 'This field is required');
            isValid = false;
        }
    });
    
    // Email validation
    const emailInput = form.querySelector('[name="email"]');
    if (emailInput && !isValidEmail(emailInput.value)) {
        showFieldError(emailInput, 'Please enter a valid email address');
        isValid = false;
    }
    
    // Phone validation (basic)
    const phoneInput = form.querySelector('[name="phone"]');
    if (phoneInput && !/^\+?[\d\s-]{10,}$/.test(phoneInput.value)) {
        showFieldError(phoneInput, 'Please enter a valid phone number');
        isValid = false;
    }
    
    if (isValid) {
        // If form is valid, you would typically submit it here
        // For now, we'll just show a success message
        showNotification('Order placed successfully!', 'success');
        // Clear cart after successful order
        cart = [];
        saveCart();
        // Redirect to receipt page after a short delay
        setTimeout(() => {
            window.location.href = 'receipt.php';
        }, 1500);
    } else {
        showNotification('Please fix the errors in the form', 'error');
    }
}

// Helper Functions
function setupQuantitySelector(container) {
    const input = container.querySelector('input');
    const minusBtn = container.querySelector('.quantity-minus');
    const plusBtn = container.querySelector('.quantity-plus');
    
    minusBtn.addEventListener('click', () => {
        const value = parseInt(input.value) || 1;
        if (value > 1) {
            input.value = value - 1;
        }
    });
    
    plusBtn.addEventListener('click', () => {
        const value = parseInt(input.value) || 1;
        input.value = value + 1;
    });
    
    // Ensure value is at least 1
    input.addEventListener('change', () => {
        const value = parseInt(input.value);
        if (isNaN(value) || value < 1) {
            input.value = 1;
        }
    });
}

function setupCartEventListeners() {
    // Handle remove item buttons
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('btn-remove')) {
            const itemId = e.target.dataset.id;
            removeFromCart(itemId);
        }
    });
    
    // Handle quantity changes in cart
    document.addEventListener('change', (e) => {
        if (e.target.classList.contains('cart-quantity')) {
            const itemId = e.target.closest('.cart-item').dataset.id;
            const newQuantity = parseInt(e.target.value) || 1;
            
            if (newQuantity < 1) {
                removeFromCart(itemId);
                return;
            }
            
            const item = cart.find(item => item.id === itemId);
            if (item) {
                item.quantity = newQuantity;
                saveCart();
                updateCartDisplay();
            }
        }
    });
}

function showFieldError(input, message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.style.color = 'var(--error-color)';
    errorElement.style.fontSize = '0.875rem';
    errorElement.style.marginTop = '0.25rem';
    
    input.classList.add('is-invalid');
    input.after(errorElement);
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type}`;
    notification.textContent = message;
    
    // Position the notification
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '1rem';
    notification.style.borderRadius = '4px';
    notification.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
    notification.style.zIndex = '1000';
    notification.style.animation = 'slideIn 0.3s ease-out';
    
    // Add styles based on type
    if (type === 'success') {
        notification.style.backgroundColor = '#d4edda';
        notification.style.color = '#155724';
        notification.style.border = '1px solid #c3e6cb';
    } else {
        notification.style.backgroundColor = '#f8d7da';
        notification.style.color = '#721c24';
        notification.style.border = '1px solid #f5c6cb';
    }
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s ease-out';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}

// Add some basic animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
    
    .is-invalid {
        border-color: var(--error-color) !important;
    }
    
    .btn-block {
        display: block;
        width: 100%;
        text-align: center;
        margin-top: 1rem;
    }
    
    .summary-row {
        display: flex;
        justify-content: space-between;
        margin: 0.5rem 0;
        padding: 0.5rem 0;
        border-bottom: 1px solid #eee;
    }
    
    .summary-row.total {
        font-size: 1.1rem;
        font-weight: bold;
        border-top: 2px solid #eee;
        margin-top: 1rem;
        padding-top: 1rem;
    }
`;
document.head.appendChild(style);
