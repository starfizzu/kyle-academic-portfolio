<?php
require_once __DIR__ . '/includes/header.php';
?>

<main class="container my-5">
    <h1 class="mb-4">About Our Cafe</h1>
    
    <section class="mb-5">
        <h2>Our Story</h2>
        <p>Welcome to our cozy cafe, where we serve delicious coffee and pastries made with love and the finest ingredients. Our journey began in 2023 with a simple mission: to create a warm, welcoming space where people can enjoy great food and drinks.</p>
    </section>
    
    <section class="mb-5">
        <h2>Our Team</h2>
        <div class="row">
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Group 8</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Block 2 - Order & Billing System</h6>
                        <p class="card-text">We are a dedicated team of students working on this project to create an efficient ordering and billing system for our cafe.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="mb-5">
        <h2>Our Values</h2>
        <ul class="list-group">
            <li class="list-group-item">Quality ingredients sourced locally</li>
            <li class="list-group-item">Exceptional customer service</li>
            <li class="list-group-item">Sustainable practices</li>
            <li class="list-group-item">Community engagement</li>
        </ul>
    </section>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
