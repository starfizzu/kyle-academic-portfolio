<?php
// Include configuration and header
require_once __DIR__ . '/includes/config.php';
$page_title = 'Welcome to JavaJam Coffee House';
?>

<?php include __DIR__ . '/includes/header.php'; ?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <h1>Welcome to JavaJam Coffee House</h1>
        <p>Experience the finest coffee in town</p>
        <a href="/menu.php" class="btn btn-accent">View Our Menu</a>
    </div>
</section>

<!-- Featured Products -->
<section class="featured-products">
    <div class="container">
        <h2 class="section-title">Our Specialties</h2>
        <div class="product-grid">
            <!-- Product 1 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="/assets/images/menu/matcha-coffee.jpg" alt="Matcha Latte">
                </div>
                <div class="product-details">
                    <h3>Matcha Latte</h3>
                    <p class="price">$4.50</p>
                    <p>Delicious green tea latte made with premium matcha powder and steamed milk.</p>
                    <a href="/menu.php#matcha" class="btn btn-outline">Learn More</a>
                </div>
            </div>
            
            <!-- Product 2 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="/assets/images/menu/pastry.jpg" alt="Fresh Pastry">
                </div>
                <div class="product-details">
                    <h3>Fresh Pastries</h3>
                    <p class="price">From $2.99</p>
                    <p>Freshly baked pastries made daily with the finest ingredients.</p>
                    <a href="/menu.php#pastries" class="btn btn-outline">View Selection</a>
                </div>
            </div>
            
            <!-- Product 3 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="/assets/images/menu/coffee-beans.jpg" alt="Specialty Coffee">
                </div>
                <div class="product-details">
                    <h3>Specialty Coffee</h3>
                    <p class="price">From $3.50</p>
                    <p>Handcrafted coffee made from single-origin beans, roasted to perfection.</p>
                    <a href="/menu.php#coffee" class="btn btn-outline">Explore Coffees</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="about-section">
    <div class="container">
        <div class="about-content">
            <div class="about-text">
                <h2>Our Story</h2>
                <p>Founded in 2010, JavaJam Coffee House has been serving the finest coffee and pastries to our beloved customers. Our commitment to quality and sustainability sets us apart from the rest.</p>
                <p>We source our beans directly from ethical farmers and roast them in-house to ensure the freshest cup of coffee every time.</p>
                <a href="/about.php" class="btn btn-outline">Learn More About Us</a>
            </div>
            <div class="about-image">
                <img src="/assets/images/banner.jpg" alt="Our Coffee Shop">
            </div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="testimonials">
    <div class="container">
        <h2 class="section-title">What Our Customers Say</h2>
        <div class="testimonial-slider">
            <div class="testimonial">
                <div class="testimonial-content">
                    <p>"The best coffee in town! I come here every morning before work. The atmosphere is amazing and the staff is super friendly."</p>
                    <div class="testimonial-author">- Sarah M.</div>
                </div>
            </div>
            <div class="testimonial">
                <div class="testimonial-content">
                    <p>"I'm a coffee enthusiast, and JavaJam never disappoints. Their single-origin pour-overs are exceptional."</p>
                    <div class="testimonial-author">- Michael T.</div>
                </div>
            </div>
            <div class="testimonial">
                <div class="testimonial-content">
                    <p>"The perfect spot to work remotely. Great WiFi, delicious coffee, and a comfortable environment."</p>
                    <div class="testimonial-author">- Jessica K.</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Location & Hours -->
<section class="location-hours">
    <div class="container">
        <div class="location-content">
            <div class="location-info">
                <h2>Visit Us</h2>
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <h3>Location</h3>
                        <p>123 Coffee Street<br>Java City, JC 12345</p>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-clock"></i>
                    <div>
                        <h3>Hours</h3>
                        <p>Monday - Friday: 6:00 AM - 9:00 PM<br>
                        Saturday - Sunday: 7:00 AM - 10:00 PM</p>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-phone"></i>
                    <div>
                        <h3>Contact</h3>
                        <p>(123) 456-7890<br>
                        info@javajam.com</p>
                    </div>
                </div>
                <a href="/contact.php" class="btn btn-outline">Get Directions</a>
            </div>
            <div class="location-map">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937933185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDQyJzQ3LjMiTiA3NMKwMDAnMjkuMiJX!5e0!3m2!1sen!2sus!4v1647538078748!5m2!1sen!2sus" 
                    width="100%" 
                    height="450" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy">
                </iframe>
            </div>
        </div>
    </div>
</section>

<!-- Newsletter Signup -->
<section class="newsletter">
    <div class="container">
        <div class="newsletter-content">
            <h2>Stay Updated</h2>
            <p>Subscribe to our newsletter for the latest updates, special offers, and events.</p>
            <form class="newsletter-form" id="newsletter-form">
                <input type="email" name="email" placeholder="Enter your email" required>
                <button type="submit" class="btn btn-accent">Subscribe</button>
            </form>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
