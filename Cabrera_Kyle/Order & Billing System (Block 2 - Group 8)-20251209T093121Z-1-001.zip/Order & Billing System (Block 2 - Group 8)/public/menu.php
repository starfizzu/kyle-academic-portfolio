<?php
// Include configuration and header
require_once __DIR__ . '/includes/config.php';

// Set page title
$page_title = 'Our Menu - JavaJam Coffee House';

// Get menu items from config
$menu_categories = [
    'coffee' => [
        'name' => 'Coffee',
        'description' => 'Freshly brewed coffee made from premium beans',
        'items' => get_menu_items('coffee')
    ],
    'food' => [
        'name' => 'Food',
        'description' => 'Delicious food items to complement your drink',
        'items' => get_menu_items('food')
    ]
];

// Handle adding items to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $item_id = (int)$_POST['item_id'];
    $quantity = (int)$_POST['quantity'];
    $option = $_POST['option'] ?? null;
    
    $item = get_menu_item($item_id);
    
    if ($item) {
        $price = $item['price'];
        $name = $item['name'];
        $options = [];
        
        // Handle item options if they exist
        if ($option && isset($item['options'][$option])) {
            $price = $item['options'][$option];
            $options['option'] = $option;
        }
        
        add_to_cart($item_id, $name, $price, $quantity, $options);
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
?>

<?php include __DIR__ . '/includes/header.php'; ?>

<main class="menu-page">
    <section class="page-header">
        <div class="container">
            <h1>Our Menu</h1>
            <p>Discover our delicious selection of coffee, tea, and pastries</p>
        </div>
    </section>

    <section class="menu-categories">
        <div class="container">
            <!-- Category Navigation -->
            <div class="category-nav">
                <ul>
                    <?php foreach ($menu_categories as $key => $category): ?>
                        <li><a href="#<?php echo $key; ?>"><?php echo $category['name']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Menu Items by Category -->
            <?php foreach ($menu_categories as $key => $category): ?>
                <div id="<?php echo $key; ?>" class="menu-category">
                    <h2 class="category-title"><?php echo $category['name']; ?></h2>
                    <p class="category-description"><?php echo $category['description']; ?></p>
                    
                    <div class="row">
                        <?php foreach ($category['items'] as $item): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100">
                                    <img src="/assets/images/menu/<?php echo $item['image']; ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo htmlspecialchars($item['name']); ?>"
                                         style="height: 200px; object-fit: cover;">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo htmlspecialchars($item['name']); ?></h5>
                                        <p class="card-text"><?php echo htmlspecialchars($item['description']); ?></p>
                                        <p class="h5"><?php echo format_price($item['price']); ?></p>
                                        
                                        <form method="POST" class="mt-3">
                                            <?php if (isset($item['options'])): ?>
                                            <div class="mb-3">
                                                <label class="form-label">Options:</label>
                                                <select name="option" class="form-select" required>
                                                    <?php foreach ($item['options'] as $option => $price): ?>
                                                    <option value="<?php echo htmlspecialchars($option); ?>">
                                                        <?php echo htmlspecialchars($option); ?> - <?php echo format_price($price); ?>
                                                    </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <?php endif; ?>
                                            
                                            <div class="input-group">
                                                <input type="number" name="quantity" value="1" min="1" class="form-control" style="max-width: 70px;">
                                                <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                                                <input type="hidden" name="add_to_cart" value="1">
                                                <button type="submit" class="btn btn-primary">Add to Cart</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Special Offers -->
    <section class="special-offers">
        <div class="container">
            <h2>Today's Specials</h2>
            <div class="offers-grid">
                <div class="offer-card">
                    <div class="offer-badge">Special</div>
                    <h3>Morning Combo</h3>
                    <p>Any coffee + croissant for just $6.99</p>
                    <small>Valid until 11am</small>
                </div>
                <div class="offer-card">
                    <div class="offer-badge">New</div>
                    <h3>Iced Matcha Latte</h3>
                    <p>Try our new refreshing matcha</p>
                    <small>Limited time only</small>
                </div>
                <div class="offer-card">
                    <div class="offer-badge">Deal</div>
                    <h3>Happy Hour</h3>
                    <p>50% off all pastries from 2-4pm</p>
                    <small>Weekdays only</small>
                </div>
            </div>
        </div>
    </section>

    <!-- Allergen Information -->
    <section class="allergen-info">
        <div class="container">
            <h2>Allergen Information</h2>
            <p>Please inform our staff if you have any food allergies or dietary restrictions. While we take precautions to prevent cross-contamination, we cannot guarantee that any item is completely free of allergens.</p>
            <div class="allergen-icons">
                <div class="allergen">
                    <i class="fas fa-seedling"></i>
                    <span>Vegetarian</span>
                </div>
                <div class="allergen">
                    <i class="fas fa-leaf"></i>
                    <span>Vegan</span>
                </div>
                <div class="allergen">
                    <i class="fas fa-bread-slice"></i>
                    <span>Gluten-Free</span>
                </div>
                <div class="allergen">
                    <i class="fas fa-cow"></i>
                    <span>Dairy-Free</span>
                </div>
                <div class="allergen">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>Nuts</span>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>

<script>
// Add to cart functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize quantity selectors
    document.querySelectorAll('.quantity-selector').forEach(selector => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('.quantity-input');
            let value = parseInt(input.value);
            
            if (this.classList.contains('plus')) {
                value++;
            } else if (this.classList.contains('minus') && value > 1) {
                value--;
            }
            
            input.value = value;
        });
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

// Function to update cart count (simplified for this example)
function updateCartCount(quantityToAdd = 0) {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        let currentCount = parseInt(cartCount.textContent) || 0;
        const newCount = currentCount + quantityToAdd;
        cartCount.textContent = newCount;
        cartCount.style.display = newCount > 0 ? 'inline-block' : 'none';
    }
}
</script>
