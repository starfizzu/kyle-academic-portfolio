<?php
require_once __DIR__ . '/includes/config.php';

$page_title = 'Your Shopping Cart - JavaJam Coffee House';

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_cart'])) {
        foreach ($_POST['quantity'] as $itemKey => $quantity) {
            update_cart_item_quantity($itemKey, $quantity);
        }
        set_flash_message('Cart updated successfully', 'success');
    } elseif (isset($_POST['remove_item']) && isset($_POST['item_key'])) {
        remove_from_cart($_POST['item_key']);
        set_flash_message('Item removed from cart', 'success');
    } elseif (isset($_POST['clear_cart'])) {
        clear_cart();
        set_flash_message('Your cart has been cleared', 'success');
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}

$cart = get_cart();
$subtotal = get_cart_subtotal();
$tax_amount = get_cart_tax();
$grand_total = get_cart_total();
?>

<?php include __DIR__ . '/includes/header.php'; ?>

<main class="cart-page">
    <div class="container">
        <h1>Your Shopping Cart</h1>
        
        <?php display_flash_message(); ?>
        
        <?php if (empty($cart)): ?>
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h2>Your cart is empty</h2>
                <p>Looks like you haven't added any items to your cart yet.</p>
                <a href="/menu.php" class="btn btn-accent">Browse Our Menu</a>
            </div>
        <?php else: ?>
            <div class="cart-container">
                <div class="cart-items">
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                        <div class="cart-header">
                            <div class="header-product">Product</div>
                            <div class="header-price">Price</div>
                            <div class="header-quantity">Quantity</div>
                            <div class="header-total">Total</div>
                            <div class="header-remove"></div>
                        </div>
                        
                        <?php foreach ($cart as $key => $item): 
                            $menu_item = get_menu_item($item['id']);
                            $image = $menu_item ? ($menu_item['image'] ?? 'default.jpg') : 'default.jpg';
                            $description = $menu_item ? ($menu_item['description'] ?? '') : '';
                        ?>
                            <div class="cart-item">
                                <div class="item-product">
                                    <img src="/assets/images/menu/<?php echo $image; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                    <div class="item-details">
                                        <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                        <?php if (!empty($item['options'])): ?>
                                            <?php foreach ($item['options'] as $optName => $optValue): ?>
                                                <p class="item-option">
                                                    <?php echo htmlspecialchars(ucfirst($optName) . ': ' . $optValue); ?>
                                                </p>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                        <p class="item-description"><?php echo htmlspecialchars($description); ?></p>
                                    </div>
                                </div>
                                <div class="item-price">
                                    <?php echo format_price($item['price']); ?>
                                </div>
                                <div class="item-quantity">
                                    <div class="quantity-selector">
                                        <button type="button" class="quantity-btn minus">-</button>
                                        <input type="number" 
                                               name="quantity[<?php echo htmlspecialchars($key); ?>]" 
                                               value="<?php echo $item['quantity']; ?>" 
                                               min="1" 
                                               class="quantity-input cart-quantity"
                                               data-item-key="<?php echo htmlspecialchars($key); ?>">
                                        <button type="button" class="quantity-btn plus">+</button>
                                    </div>
                                </div>
                                <div class="item-total">
                                    <?php echo format_price($item['price'] * $item['quantity']); ?>
                                </div>
                                <div class="item-remove">
                                    <button type="submit" name="remove_item" class="remove-btn" title="Remove item">
                                        <i class="fas fa-times"></i>
                                    </button>
                                    <input type="hidden" name="item_key" value="<?php echo htmlspecialchars($key); ?>">
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <div class="cart-actions">
                            <a href="/menu.php" class="btn btn-outline">
                                <i class="fas fa-arrow-left"></i> Continue Shopping
                            </a>
                            <button type="submit" name="update_cart" class="btn btn-outline">
                                <i class="fas fa-sync-alt"></i> Update Cart
                            </button>
                            <button type="submit" name="clear_cart" class="btn btn-outline" onclick="return confirm('Are you sure you want to clear your cart?');">
                                <i class="fas fa-trash"></i> Clear Cart
                            </button>
                        </div>
                    </form>
                </div>
                
                <div class="cart-summary">
                    <h3>Order Summary</h3>
                    <div class="summary-row">
                        <span>Subtotal (<?php echo get_cart_item_count(); ?> items):</span>
                        <span><?php echo format_price($subtotal); ?></span>
                    </div>
                    <div class="summary-row">
                        <span>Tax (8%):</span>
                        <span><?php echo format_price($tax_amount); ?></span>
                    </div>
                    <div class="summary-row total">
                        <strong>Total:</strong>
                        <strong><?php echo format_price($grand_total); ?></strong>
                    </div>
                    <a href="/checkout.php" class="btn btn-accent btn-block">
                        Proceed to Checkout <i class="fas fa-arrow-right"></i>
                    </a>
                    
                    <div class="payment-methods">
                        <p>We accept:</p>
                        <div class="payment-icons">
                            <i class="fab fa-cc-visa" title="Visa"></i>
                            <i class="fab fa-cc-mastercard" title="Mastercard"></i>
                            <i class="fab fa-cc-amex" title="American Express"></i>
                            <i class="fab fa-cc-paypal" title="PayPal"></i>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Quantity selector functionality
    document.querySelectorAll('.quantity-selector').forEach(selector => {
        const input = selector.querySelector('input');
        const minusBtn = selector.querySelector('.minus');
        const plusBtn = selector.querySelector('.plus');
        
        if (minusBtn) {
            minusBtn.addEventListener('click', () => {
                const value = parseInt(input.value) || 1;
                if (value > 1) {
                    input.value = value - 1;
                    input.dispatchEvent(new Event('change'));
                }
            });
        }
        
        if (plusBtn) {
            plusBtn.addEventListener('click', () => {
                const value = parseInt(input.value) || 1;
                input.value = value + 1;
                input.dispatchEvent(new Event('change'));
            });
        }
        
        if (input) {
            input.addEventListener('change', () => {
                const value = parseInt(input.value);
                if (isNaN(value) || value < 1) {
                    input.value = 1;
                }
                
                // Submit the form when quantity changes
                const form = input.closest('form');
                if (form) {
                    // Add the update_cart parameter
                    const updateInput = document.createElement('input');
                    updateInput.type = 'hidden';
                    updateInput.name = 'update_cart';
                    updateInput.value = '1';
                    form.appendChild(updateInput);
                    
                    // Submit the form
                    form.submit();
                }
            });
        }
    });
    
    // Remove item from cart
    document.querySelectorAll('.remove-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to remove this item from your cart?')) {
                e.preventDefault();
            }
        });
    });
});
</script>
