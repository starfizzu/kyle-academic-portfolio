<?php
/**
 * Application Configuration
 * 
 * Contains application settings, menu data, and core functions
 * for the JavaJam Coffee House application.
 */

// Error reporting for development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Menu data
$menu_items = [
    'coffee' => [
        [
            'id' => 1,
            'name' => 'Just Java',
            'description' => 'Regular house blend, decaffeinated coffee, or flavor of the day.',
            'price' => 2.00,
            'image' => 'just-java.jpg'
        ],
        [
            'id' => 2,
            'name' => 'Cafe au Lait',
            'description' => 'House blended coffee infused into a smooth, steamed milk.',
            'price' => 2.00,
            'options' => [
                'Single' => 2.00,
                'Double' => 3.00
            ],
            'image' => 'cafe-au-lait.jpg'
        ],
        [
            'id' => 3,
            'name' => 'Iced Cappuccino',
            'description' => 'Sweetened espresso blended with icy-cold milk and served in a chilled glass.',
            'price' => 4.75,
            'options' => [
                'Single' => 4.75,
                'Double' => 5.75
            ],
            'image' => 'iced-cappuccino.jpg'
        ]
    ],
    'food' => [
        [
            'id' => 4,
            'name' => 'Bagel',
            'description' => 'Freshly baked bagel with your choice of cream cheese.',
            'price' => 3.50,
            'image' => 'bagel.jpg'
        ],
        [
            'id' => 5,
            'name' => 'Muffin',
            'description' => 'Freshly baked blueberry or bran muffin.',
            'price' => 2.50,
            'image' => 'muffin.jpg'
        ]
    ]
];

/**
 * Get menu items by category or all items
 */
function get_menu_items($category = null) {
    global $menu_items;
    if ($category) {
        return $menu_items[$category] ?? [];
    }
    return $menu_items;
}

/**
 * Get a single menu item by ID
 */
function get_menu_item($id) {
    global $menu_items;
    foreach ($menu_items as $category) {
        foreach ($category as $item) {
            if ($item['id'] == $id) {
                return $item;
            }
        }
    }
    return null;
}

/**
 * Set a flash message to be displayed on the next page load
 *
 * @param string $message The message to display
 * @param string $type The type of message (success, error, warning, info)
 * @return void
 */
function set_flash_message($message, $type = 'info') {
    $_SESSION['flash'] = [
        'message' => $message,
        'type' => $type
    ];
}

/**
 * Display a flash message if one exists
 *
 * @return void
 */
function display_flash_message() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        echo '<div class="alert alert-' . htmlspecialchars($flash['type']) . ' alert-dismissible fade show" role="alert">';
        echo htmlspecialchars($flash['message']);
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        echo '</div>';
        
        // Clear the flash message after displaying
        unset($_SESSION['flash']);
    }
}

/**
 * Redirect to a different page
 *
 * @param string $url The URL to redirect to
 * @param int $statusCode HTTP status code (default: 302)
 * @return void
 */
function redirect($url, $statusCode = 302) {
    header('Location: ' . $url, true, $statusCode);
    exit();
}

/**
 * Sanitize user input
 *
 * @param string $data The data to sanitize
 * @return string The sanitized data
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Format price with currency symbol
 *
 * @param float $amount The amount to format
 * @return string Formatted price with $ symbol
 */
function format_price($amount) {
    return '$' . number_format($amount, 2);
}

/**
 * Get the current cart or create a new one if it doesn't exist
 *
 * @return array The cart array
 */
function get_cart() {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

/**
 * Add an item to the cart
 *
 * @param int $item_id The ID of the item to add
 * @param string $name The name of the item
 * @param float $price The price of the item
 * @param int $quantity The quantity to add (default: 1)
 * @param array $options Any options for the item (e.g., size, milk type)
 * @return void
 */
function add_to_cart($item_id, $name, $price, $quantity = 1, $options = []) {
    $cart = get_cart();
    $found = false;
    
    // Generate a unique key for this item with its options
    $options_key = md5(json_encode($options));
    $item_key = $item_id . '_' . $options_key;
    
    // Check if item with same options already in cart
    foreach ($cart as &$item) {
        if ($item['key'] === $item_key) {
            $item['quantity'] += $quantity;
            $found = true;
            break;
        }
    }
    
    // Add new item if not found
    if (!$found) {
        $cart[] = [
            'key' => $item_key,
            'id' => $item_id,
            'name' => $name,
            'price' => $price,
            'quantity' => $quantity,
            'options' => $options
        ];
    }
    
    $_SESSION['cart'] = $cart;
    set_flash_message("$name added to cart!", 'success');
}

function remove_from_cart($item_key) {
    $cart = get_cart();
    $new_cart = [];
    $removed = false;
    
    foreach ($cart as $item) {
        if ($item['key'] !== $item_key) {
            $new_cart[] = $item;
        } else {
            $removed = true;
        }
    }
    
    if ($removed) {
        $_SESSION['cart'] = $new_cart;
        set_flash_message("Item removed from cart.", 'info');
    }
    
    return $removed;
}

/**
 * Update the quantity of an item in the cart
 *
 * @param string $item_key The unique key of the item to update
 * @param int $quantity The new quantity
 * @return bool True if item was updated, false otherwise
 */
function update_cart_item_quantity($item_key, $quantity) {
    $cart = get_cart();
    $updated = false;
    
    if ($quantity <= 0) {
        return remove_from_cart($item_key);
    }
    
    foreach ($cart as &$item) {
        if ($item['key'] === $item_key) {
            $item['quantity'] = (int)$quantity;
            $updated = true;
            break;
        }
    }
    
    if ($updated) {
        $_SESSION['cart'] = $cart;
    }
    
    return $updated;
}

/**
 * Calculate the subtotal of items in the cart
 *
 * @return float The subtotal price
 */
function get_cart_subtotal() {
    $cart = get_cart();
    $subtotal = 0;
    
    foreach ($cart as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    
    return $subtotal;
}

/**
 * Calculate the total price including tax
 *
 * @return float The total price with tax
 */
function get_cart_total() {
    $subtotal = get_cart_subtotal();
    $tax_rate = 0.08; // 8% tax rate
    return $subtotal * (1 + $tax_rate);
}

/**
 * Get the tax amount for the cart
 *
 * @return float The tax amount
 */
function get_cart_tax() {
    $subtotal = get_cart_subtotal();
    $tax_rate = 0.08; // 8% tax rate
    return $subtotal * $tax_rate;
}

/**
 * Clear all items from the cart
 *
 * @return void
 */
function clear_cart() {
    $_SESSION['cart'] = [];
}

/**
 * Get the number of items in the cart
 *
 * @return int The number of items in the cart
 */
function get_cart_item_count() {
    $cart = get_cart();
    $count = 0;
    
    foreach ($cart as $item) {
        $count += $item['quantity'];
    }
    
    return $count;
}

// All necessary functions are defined in this file

// Check if this is an AJAX request
function is_ajax_request() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}
