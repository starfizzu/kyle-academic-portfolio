<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current page name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JavaJam Coffee House</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <nav class="navbar">
                <div class="logo">
                    <a href="/index.php">
                        <img src="/assets/images/logo.png" alt="JavaJam Coffee House" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                        JavaJam Coffee House
                    </a>
                </div>
                <ul class="nav-links">
                    <li><a href="/index.php" class="<?= $current_page === 'index.php' ? 'active' : '' ?>">Home</a></li>
                    <li><a href="/menu.php" class="<?= $current_page === 'menu.php' ? 'active' : '' ?>">Menu</a></li>
                    <li><a href="/about.php" class="<?= $current_page === 'about.php' ? 'active' : '' ?>">About</a></li>
                    <li><a href="/contact.php" class="<?= $current_page === 'contact.php' ? 'active' : '' ?>">Contact</a></li>
                    <li>
                        <a href="/cart.php" class="cart-link">
                            <i class="fas fa-shopping-cart"></i>
                            <span id="cart-count" class="cart-count" style="display: none;">0</span>
                        </a>
                    </li>
                </ul>
                <div class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <main class="container">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
                <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                ?>
            </div>
        <?php endif; ?>
