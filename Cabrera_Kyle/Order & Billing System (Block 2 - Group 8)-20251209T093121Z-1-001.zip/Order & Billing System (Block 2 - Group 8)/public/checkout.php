<?php
require_once __DIR__ . '/includes/config.php';

$page_title = 'Checkout - JavaJam Coffee House';

// Redirect to menu if cart is empty
$cart = get_cart();
if (empty($cart)) {
    set_flash_message('Your cart is empty. Please add some items before checking out.', 'error');
    header('Location: /menu.php');
    exit();
}

// Calculate order totals
$subtotal = get_cart_total();
$tax_rate = 0.10; // 10% tax
$tax_amount = $subtotal * $tax_rate;
$grand_total = $subtotal + $tax_amount;

// Form processing
$errors = [];
$form_data = [
    'first_name' => '',
    'last_name' => '',
    'email' => '',
    'phone' => '',
    'address' => '',
    'city' => '',
    'state' => '',
    'zip_code' => '',
    'delivery_method' => 'pickup',
    'payment_method' => 'credit_card',
    'card_number' => '',
    'card_expiry' => '',
    'card_cvv' => '',
    'special_instructions' => ''
];

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input
    $form_data = array_map('trim', $_POST);
    
    // Required fields validation
    $required_fields = ['first_name', 'last_name', 'email', 'phone', 'payment_method'];
    
    // If delivery is selected, require address fields
    if (isset($form_data['delivery_method']) && $form_data['delivery_method'] === 'delivery') {
        $required_fields = array_merge($required_fields, ['address', 'city', 'state', 'zip_code']);
    }
    
    // If credit card is selected, require card details
    if (isset($form_data['payment_method']) && $form_data['payment_method'] === 'credit_card') {
        $required_fields = array_merge($required_fields, ['card_number', 'card_expiry', 'card_cvv']);
    }
    
    // Check required fields
    foreach ($required_fields as $field) {
        if (empty($form_data[$field])) {
            $errors[$field] = 'This field is required';
        }
    }
    
    // Validate email
    if (!filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address';
    }
    
    // Validate phone (basic validation)
    if (!preg_match('/^[0-9\-\+\(\)\s]{10,20}$/', $form_data['phone'])) {
        $errors['phone'] = 'Please enter a valid phone number';
    }
    
    // If no errors, process the order
    if (empty($errors)) {
        // In a real application, you would:
        // 1. Process payment
        // 2. Save order to database
        // 3. Send confirmation email
        // 4. Clear the cart
        // 5. Redirect to receipt page with order details
        
        // For now, we'll just redirect to the receipt page
        $_SESSION['order_details'] = [
            'order_id' => 'ORD' . strtoupper(uniqid()),
            'customer_name' => $form_data['first_name'] . ' ' . $form_data['last_name'],
            'email' => $form_data['email'],
            'phone' => $form_data['phone'],
            'delivery_method' => $form_data['delivery_method'],
            'delivery_address' => $form_data['delivery_method'] === 'delivery' ? 
                $form_data['address'] . ', ' . $form_data['city'] . ', ' . $form_data['state'] . ' ' . $form_data['zip_code'] : 
                'In-Store Pickup',
            'order_total' => $grand_total,
            'items' => $cart,
            'order_date' => date('F j, Y \a\t g:i A')
        ];
        
        // Clear the cart
        clear_cart();
        
        // Redirect to receipt page
        header('Location: /receipt.php');
        exit();
    }
}
?>

<?php include __DIR__ . '/includes/header.php'; ?>

<main class="checkout-page">
    <div class="container">
        <div class="checkout-header">
            <h1>Checkout</h1>
            <div class="checkout-steps">
                <div class="step active">
                    <span class="step-number">1</span>
                    <span class="step-text">Your Order</span>
                </div>
                <div class="step active">
                    <span class="step-number">2</span>
                    <span class="step-text">Billing & Payment</span>
                </div>
                <div class="step">
                    <span class="step-number">3</span>
                    <span class="step-text">Confirmation</span>
                </div>
            </div>
        </div>
        
        <div class="checkout-container">
            <div class="checkout-form-container">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="checkout-form" class="needs-validation" novalidate>
                    <div class="checkout-section">
                        <h2>Contact Information</h2>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="first_name">First Name *</label>
                                <input type="text" class="form-control <?php echo isset($errors['first_name']) ? 'is-invalid' : ''; ?>" 
                                       id="first_name" name="first_name" 
                                       value="<?php echo htmlspecialchars($form_data['first_name']); ?>" required>
                                <?php if (isset($errors['first_name'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['first_name']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="last_name">Last Name *</label>
                                <input type="text" class="form-control <?php echo isset($errors['last_name']) ? 'is-invalid' : ''; ?>" 
                                       id="last_name" name="last_name" 
                                       value="<?php echo htmlspecialchars($form_data['last_name']); ?>" required>
                                <?php if (isset($errors['last_name'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['last_name']; ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="email">Email Address *</label>
                                <input type="email" class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>" 
                                       id="email" name="email" 
                                       value="<?php echo htmlspecialchars($form_data['email']); ?>" required>
                                <?php if (isset($errors['email'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['email']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="phone">Phone Number *</label>
                                <input type="tel" class="form-control <?php echo isset($errors['phone']) ? 'is-invalid' : ''; ?>" 
                                       id="phone" name="phone" 
                                       value="<?php echo htmlspecialchars($form_data['phone']); ?>" required>
                                <?php if (isset($errors['phone'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['phone']; ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="checkout-section">
                        <h2>Delivery Method</h2>
                        <div class="delivery-options">
                            <div class="form-check delivery-option">
                                <input class="form-check-input" type="radio" name="delivery_method" 
                                       id="pickup" value="pickup" 
                                       <?php echo ($form_data['delivery_method'] ?? 'pickup') === 'pickup' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="pickup">
                                    <i class="fas fa-store"></i>
                                    <div>
                                        <h4>Pickup in Store</h4>
                                        <p>Pick up your order at our coffee shop</p>
                                        <p class="text-muted">123 Coffee Street, Java City</p>
                                    </div>
                                </label>
                            </div>
                            <div class="form-check delivery-option">
                                <input class="form-check-input" type="radio" name="delivery_method" 
                                       id="delivery" value="delivery"
                                       <?php echo ($form_data['delivery_method'] ?? '') === 'delivery' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="delivery">
                                    <i class="fas fa-truck"></i>
                                    <div>
                                        <h4>Home Delivery</h4>
                                        <p>Get your order delivered to your doorstep</p>
                                        <p class="text-muted">Delivery fee may apply</p>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <div id="delivery-address" style="display: <?php echo ($form_data['delivery_method'] ?? '') === 'delivery' ? 'block' : 'none'; ?>;">
                            <h3 class="mt-4">Delivery Address</h3>
                            <div class="form-group">
                                <label for="address">Street Address *</label>
                                <input type="text" class="form-control <?php echo isset($errors['address']) ? 'is-invalid' : ''; ?>" 
                                       id="address" name="address" 
                                       value="<?php echo htmlspecialchars($form_data['address']); ?>">
                                <?php if (isset($errors['address'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['address']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="city">City *</label>
                                    <input type="text" class="form-control <?php echo isset($errors['city']) ? 'is-invalid' : ''; ?>" 
                                           id="city" name="city" 
                                           value="<?php echo htmlspecialchars($form_data['city']); ?>">
                                    <?php if (isset($errors['city'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['city']; ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="state">State *</label>
                                    <select class="form-control <?php echo isset($errors['state']) ? 'is-invalid' : ''; ?>" 
                                            id="state" name="state">
                                        <option value="">Select State</option>
                                        <option value="AL" <?php echo ($form_data['state'] ?? '') === 'AL' ? 'selected' : ''; ?>>Alabama</option>
                                        <option value="AK" <?php echo ($form_data['state'] ?? '') === 'AK' ? 'selected' : ''; ?>>Alaska</option>
                                        <!-- Add more states as needed -->
                                        <option value="NY" <?php echo ($form_data['state'] ?? '') === 'NY' ? 'selected' : ''; ?>>New York</option>
                                        <option value="CA" <?php echo ($form_data['state'] ?? '') === 'CA' ? 'selected' : ''; ?>>California</option>
                                    </select>
                                    <?php if (isset($errors['state'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['state']; ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="zip_code">ZIP Code *</label>
                                    <input type="text" class="form-control <?php echo isset($errors['zip_code']) ? 'is-invalid' : ''; ?>" 
                                           id="zip_code" name="zip_code" 
                                           value="<?php echo htmlspecialchars($form_data['zip_code']); ?>">
                                    <?php if (isset($errors['zip_code'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['zip_code']; ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="checkout-section">
                        <h2>Payment Method</h2>
                        <div class="payment-options">
                            <div class="form-check payment-option">
                                <input class="form-check-input" type="radio" name="payment_method" 
                                       id="credit_card" value="credit_card" 
                                       <?php echo ($form_data['payment_method'] ?? 'credit_card') === 'credit_card' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="credit_card">
                                    <i class="far fa-credit-card"></i>
                                    <span>Credit/Debit Card</span>
                                </label>
                            </div>
                            <div class="form-check payment-option">
                                <input class="form-check-input" type="radio" name="payment_method" 
                                       id="paypal" value="paypal"
                                       <?php echo ($form_data['payment_method'] ?? '') === 'paypal' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="paypal">
                                    <i class="fab fa-paypal"></i>
                                    <span>PayPal</span>
                                </label>
                            </div>
                            <div class="form-check payment-option">
                                <input class="form-check-input" type="radio" name="payment_method" 
                                       id="cash" value="cash"
                                       <?php echo ($form_data['payment_method'] ?? '') === 'cash' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="cash">
                                    <i class="fas fa-money-bill-wave"></i>
                                    <span>Cash on Delivery</span>
                                </label>
                            </div>
                        </div>
                        
                        <div id="credit-card-details" style="display: <?php echo ($form_data['payment_method'] ?? 'credit_card') === 'credit_card' ? 'block' : 'none'; ?>">
                            <div class="form-row mt-4">
                                <div class="form-group col-md-12">
                                    <label for="card_number">Card Number *</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control <?php echo isset($errors['card_number']) ? 'is-invalid' : ''; ?>" 
                                               id="card_number" name="card_number" 
                                               value="<?php echo htmlspecialchars($form_data['card_number']); ?>"
                                               placeholder="1234 5678 9012 3456">
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <i class="fab fa-cc-visa" id="card-type-visa" style="display: none;"></i>
                                                <i class="fab fa-cc-mastercard" id="card-type-mastercard" style="display: none;"></i>
                                                <i class="fab fa-cc-amex" id="card-type-amex" style="display: none;"></i>
                                                <i class="fas fa-credit-card" id="card-type-generic"></i>
                                            </span>
                                        </div>
                                        <?php if (isset($errors['card_number'])): ?>
                                            <div class="invalid-feedback"><?php echo $errors['card_number']; ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="card_expiry">Expiration Date *</label>
                                    <input type="text" class="form-control <?php echo isset($errors['card_expiry']) ? 'is-invalid' : ''; ?>" 
                                           id="card_expiry" name="card_expiry" 
                                           value="<?php echo htmlspecialchars($form_data['card_expiry']); ?>"
                                           placeholder="MM/YY">
                                    <?php if (isset($errors['card_expiry'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['card_expiry']; ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="card_cvv">CVV *</label>
                                    <input type="text" class="form-control <?php echo isset($errors['card_cvv']) ? 'is-invalid' : ''; ?>" 
                                           id="card_cvv" name="card_cvv" 
                                           value="<?php echo htmlspecialchars($form_data['card_cvv']); ?>"
                                           placeholder="123" maxlength="4">
                                    <?php if (isset($errors['card_cvv'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['card_cvv']; ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="card_name">Name on Card *</label>
                                <input type="text" class="form-control" 
                                       id="card_name" name="card_name" 
                                       value="<?php echo htmlspecialchars(($form_data['first_name'] ?? '') . ' ' . ($form_data['last_name'] ?? '')); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="checkout-section">
                        <h2>Special Instructions</h2>
                        <div class="form-group">
                            <label for="special_instructions">Add special instructions for your order (optional)</label>
                            <textarea class="form-control" id="special_instructions" name="special_instructions" 
                                      rows="3" placeholder="Any special requests or delivery instructions..."><?php echo htmlspecialchars($form_data['special_instructions']); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="terms_agreed" name="terms_agreed" required>
                        <label class="form-check-label" for="terms_agreed">
                            I agree to the <a href="/terms.php" target="_blank">Terms and Conditions</a> and 
                            <a href="/privacy.php" target="_blank">Privacy Policy</a> *
                        </label>
                        <div class="invalid-feedback">You must agree to the terms and conditions</div>
                    </div>
                    
                    <div class="checkout-actions">
                        <a href="/cart.php" class="btn btn-outline">
                            <i class="fas fa-arrow-left"></i> Back to Cart
                        </a>
                        <button type="submit" class="btn btn-accent">
                            Place Order <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </form>
            </div>
            
            <div class="order-summary">
                <h3>Order Summary</h3>
                <div class="order-items">
                    <?php foreach ($cart as $item): ?>
                        <div class="order-item">
                            <div class="item-quantity"><?php echo $item['quantity']; ?>x</div>
                            <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                            <div class="item-price">$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="order-totals">
                    <div class="order-row">
                        <span>Subtotal</span>
                        <span>$<?php echo number_format($subtotal, 2); ?></span>
                    </div>
                    <div class="order-row">
                        <span>Tax (10%)</span>
                        <span>$<?php echo number_format($tax_amount, 2); ?></span>
                    </div>
                    <div class="order-row delivery-fee" style="display: <?php echo ($form_data['delivery_method'] ?? '') === 'delivery' ? 'flex' : 'none'; ?>">
                        <span>Delivery Fee</span>
                        <span>$3.99</span>
                    </div>
                    <div class="order-row total">
                        <strong>Total</strong>
                        <strong>$<?php 
                            $final_total = ($form_data['delivery_method'] ?? '') === 'delivery' ? $grand_total + 3.99 : $grand_total;
                            echo number_format($final_total, 2); 
                        ?></strong>
                    </div>
                </div>
                
                <div class="secure-checkout">
                    <i class="fas fa-lock"></i>
                    <span>Secure Checkout</span>
                    <p>Your payment information is encrypted and secure.</p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle delivery address fields
    const deliveryMethod = document.querySelectorAll('input[name="delivery_method"]');
    const deliveryAddress = document.getElementById('delivery-address');
    const deliveryFee = document.querySelector('.delivery-fee');
    
    deliveryMethod.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.value === 'delivery') {
                deliveryAddress.style.display = 'block';
                deliveryFee.style.display = 'flex';
                updateOrderTotal(true);
            } else {
                deliveryAddress.style.display = 'none';
                deliveryFee.style.display = 'none';
                updateOrderTotal(false);
            }
        });
    });
    
    // Toggle payment method fields
    const paymentMethod = document.querySelectorAll('input[name="payment_method"]');
    const creditCardDetails = document.getElementById('credit-card-details');
    
    paymentMethod.forEach(radio => {
        radio.addEventListener('change', function() {
            creditCardDetails.style.display = this.value === 'credit_card' ? 'block' : 'none';
        });
    });
    
    // Format card number
    const cardNumber = document.getElementById('card_number');
    if (cardNumber) {
        cardNumber.addEventListener('input', function(e) {
            // Remove all non-digits
            let value = this.value.replace(/\D/g, '');
            
            // Add spaces after every 4 digits
            value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
            
            // Update the input value
            this.value = value.trim();
            
            // Update card type icon
            updateCardType(value);
        });
    }
    
    // Format expiry date
    const cardExpiry = document.getElementById('card_expiry');
    if (cardExpiry) {
        cardExpiry.addEventListener('input', function(e) {
            let value = this.value.replace(/\D/g, '');
            
            // Add slash after MM
            if (value.length > 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            
            this.value = value;
        });
    }
    
    // Format CVV
    const cardCvv = document.getElementById('card_cvv');
    if (cardCvv) {
        cardCvv.addEventListener('input', function(e) {
            this.value = this.value.replace(/\D/g, '').substring(0, 4);
        });
    }
    
    // Form validation
    const form = document.getElementById('checkout-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    }
    
    // Update order total when delivery method changes
    function updateOrderTotal(includeDelivery) {
        const totalElement = document.querySelector('.order-totals .total strong:last-child');
        if (totalElement) {
            const baseTotal = <?php echo $grand_total; ?>;
            const deliveryFee = includeDelivery ? 3.99 : 0;
            const newTotal = baseTotal + deliveryFee;
            totalElement.textContent = '$' + newTotal.toFixed(2);
        }
    }
    
    // Update card type icon based on card number
    function updateCardType(cardNumber) {
        const cardTypeIcons = {
            'visa': document.getElementById('card-type-visa'),
            'mastercard': document.getElementById('card-type-mastercard'),
            'amex': document.getElementById('card-type-amex'),
            'generic': document.getElementById('card-type-generic')
        };
        
        // Hide all icons first
        Object.values(cardTypeIcons).forEach(icon => {
            if (icon) icon.style.display = 'none';
        });
        
        // Show the appropriate icon based on card number
        const firstDigit = cardNumber.charAt(0);
        if (firstDigit === '4') {
            if (cardTypeIcons.visa) cardTypeIcons.visa.style.display = 'inline-block';
        } else if (firstDigit === '5') {
            if (cardTypeIcons.mastercard) cardTypeIcons.mastercard.style.display = 'inline-block';
        } else if (firstDigit === '3') {
            if (cardTypeIcons.amex) cardTypeIcons.amex.style.display = 'inline-block';
        } else {
            if (cardTypeIcons.generic) cardTypeIcons.generic.style.display = 'inline-block';
        }
    }
});
</script>
