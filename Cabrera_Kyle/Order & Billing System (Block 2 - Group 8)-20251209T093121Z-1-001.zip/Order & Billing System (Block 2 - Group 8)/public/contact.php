<?php
require_once __DIR__ . '/includes/header.php';

// Handle form submission
$messageSent = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Basic form validation
    $name = trim($_POST['name'] ?? '');
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    if (empty($name) || !$email || empty($subject) || empty($message)) {
        $error = 'Please fill in all required fields with valid information.';
    } else {
        // In a real application, you would process the form here
        // For now, we'll just set a success message
        $messageSent = true;
    }
}
?>

<main class="container my-5">
    <h1 class="mb-4">Contact Us</h1>
    
    <div class="row">
        <div class="col-md-6">
            <?php if ($messageSent): ?>
                <div class="alert alert-success">
                    Thank you for your message! We'll get back to you soon.
                </div>
            <?php elseif ($error): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="contact.php" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="name" class="form-label">Name *</label>
                    <input type="text" class="form-control" id="name" name="name" required 
                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                    <div class="invalid-feedback">
                        Please provide your name.
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email *</label>
                    <input type="email" class="form-control" id="email" name="email" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    <div class="invalid-feedback">
                        Please provide a valid email address.
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="subject" class="form-label">Subject *</label>
                    <input type="text" class="form-control" id="subject" name="subject" required
                           value="<?php echo isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>">
                    <div class="invalid-feedback">
                        Please provide a subject.
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="message" class="form-label">Message *</label>
                    <textarea class="form-control" id="message" name="message" rows="5" required><?php 
                        echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; 
                    ?></textarea>
                    <div class="invalid-feedback">
                        Please enter your message.
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>
        
        <div class="col-md-5 offset-md-1 mt-4 mt-md-0">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Visit Us</h5>
                    <p class="card-text">
                        <i class="bi bi-geo-alt-fill me-2"></i> 123 Cafe Street<br>
                        <span class="ms-4">Foodie City, FC 12345</span>
                    </p>
                    <p class="card-text">
                        <i class="bi bi-telephone-fill me-2"></i> (123) 456-7890
                    </p>
                    <p class="card-text">
                        <i class="bi bi-envelope-fill me-2"></i> info@cafesystem.com
                    </p>
                    <hr>
                    <h5>Opening Hours</h5>
                    <p class="mb-1">Monday - Friday: 7:00 AM - 9:00 PM</p>
                    <p class="mb-1">Saturday - Sunday: 8:00 AM - 10:00 PM</p>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
// Client-side form validation
(function () {
    'use strict'
    
    const forms = document.querySelectorAll('.needs-validation')
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
