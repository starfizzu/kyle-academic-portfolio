<?php
require_once __DIR__ . '/includes/config.php';

// Redirect to home if no order details are found
if (!isset($_SESSION['order_details'])) {
    header('Location: /index.php');
    exit();
}

$order = $_SESSION['order_details'];
$page_title = 'Order Confirmation - JavaJam Coffee House';

// Clear the order details from session after displaying
unset($_SESSION['order_details']);
?>

<?php include __DIR__ . '/includes/header.php'; ?>

<main class="receipt-page">
    <div class="container">
        <div class="receipt-container">
            <div class="receipt-header text-center">
                <div class="checkmark">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h1>Thank You for Your Order!</h1>
                <p class="order-number">Order #<?php echo htmlspecialchars($order['order_id']); ?></p>
                <p class="confirmation-msg">Your order has been received and is being processed. We'll send you a confirmation email shortly.</p>
            </div>
            
            <div class="receipt-details">
                <div class="row">
                    <div class="col-md-6">
                        <div class="detail-box">
                            <h3>Order Information</h3>
                            <div class="detail-row">
                                <span class="label">Order Number:</span>
                                <span class="value"><?php echo htmlspecialchars($order['order_id']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="label">Date:</span>
                                <span class="value"><?php echo $order['order_date']; ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="label">Status:</span>
                                <span class="badge badge-processing">Processing</span>
                            </div>
                            <div class="detail-row">
                                <span class="label">Payment Method:</span>
                                <span class="value">
                                    <?php 
                                    $payment_method = $order['payment_method'] ?? 'Credit Card';
                                    echo ucfirst(str_replace('_', ' ', $payment_method)); 
                                    ?>
                                </span>
                            </div>
                            <div class="detail-row">
                                <span class="label">Total Paid:</span>
                                <span class="value total-amount">$<?php echo number_format($order['order_total'], 2); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="detail-box">
                            <h3>Customer Information</h3>
                            <div class="detail-row">
                                <span class="label">Name:</span>
                                <span class="value"><?php echo htmlspecialchars($order['customer_name']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="label">Email:</span>
                                <span class="value"><?php echo htmlspecialchars($order['email']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="label">Phone:</span>
                                <span class="value"><?php echo htmlspecialchars($order['phone']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="label"><?php echo $order['delivery_method'] === 'delivery' ? 'Delivery Address:' : 'Pickup Location:'; ?></span>
                                <span class="value"><?php echo htmlspecialchars($order['delivery_address']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="order-summary">
                    <h3>Order Summary</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th class="text-right">Price</th>
                                    <th class="text-center">Qty</th>
                                    <th class="text-right">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($order['items'] as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="product-info">
                                                <img src="/assets/images/menu/<?php echo $item['image'] ?? 'default.jpg'; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                                <div>
                                                    <h5><?php echo htmlspecialchars($item['name']); ?></h5>
                                                    <?php if (!empty($item['options'])): ?>
                                                        <div class="item-options">
                                                            <?php foreach ($item['options'] as $option): ?>
                                                                <span><?php echo htmlspecialchars($option); ?></span>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-right">$<?php echo number_format($item['price'], 2); ?></td>
                                        <td class="text-center"><?php echo $item['quantity']; ?></td>
                                        <td class="text-right">$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-right">Subtotal:</td>
                                    <td class="text-right">$<?php echo number_format($order['order_total'] / 1.1, 2); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-right">Tax (10%):</td>
                                    <td class="text-right">$<?php echo number_format($order['order_total'] * 0.1, 2); ?></td>
                                </tr>
                                <?php if ($order['delivery_method'] === 'delivery'): ?>
                                    <tr>
                                        <td colspan="3" class="text-right">Delivery Fee:</td>
                                        <td class="text-right">$3.99</td>
                                    </tr>
                                <?php endif; ?>
                                <tr class="total-row">
                                    <td colspan="3" class="text-right"><strong>Total:</strong></td>
                                    <td class="text-right"><strong>$<?php 
                                        $total = $order['delivery_method'] === 'delivery' ? $order['order_total'] + 3.99 : $order['order_total'];
                                        echo number_format($total, 2); 
                                    ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                
                <div class="delivery-info">
                    <div class="delivery-method">
                        <i class="fas <?php echo $order['delivery_method'] === 'delivery' ? 'fa-truck' : 'fa-store'; ?>"></i>
                        <div>
                            <h4><?php echo $order['delivery_method'] === 'delivery' ? 'Delivery' : 'Pickup'; ?> Information</h4>
                            <?php if ($order['delivery_method'] === 'delivery'): ?>
                                <p>Your order will be delivered within 30-45 minutes to:</p>
                                <p><strong><?php echo htmlspecialchars($order['delivery_address']); ?></strong></p>
                            <?php else: ?>
                                <p>Your order will be ready for pickup at:</p>
                                <p><strong>JavaJam Coffee House</strong><br>
                                123 Coffee Street, Java City<br>
                                Open: Mon-Sun 7:00 AM - 10:00 PM</p>
                                <p>Please bring your order number and a valid ID.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="receipt-actions text-center">
                    <a href="/index.php" class="btn btn-outline">
                        <i class="fas fa-home"></i> Back to Home
                    </a>
                    <a href="/menu.php" class="btn btn-accent">
                        <i class="fas fa-utensils"></i> Order Again
                    </a>
                    <button class="btn btn-print" onclick="window.print()">
                        <i class="fas fa-print"></i> Print Receipt
                    </button>
                </div>
                
                <div class="receipt-footer">
                    <h4>Need Help?</h4>
                    <p>If you have any questions about your order, please contact our customer service at <a href="tel:+1234567890">(123) 456-7890</a> or email us at <a href="mailto:support@javajam.com">support@javajam.com</a>.</p>
                    <p>We appreciate your business and hope to serve you again soon!</p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>

<style>
/* Print-specific styles */
@media print {
    .no-print, .navbar, footer {
        display: none !important;
    }
    
    .receipt-container {
        width: 100%;
        max-width: 100%;
        padding: 0;
        margin: 0;
        border: none;
        box-shadow: none;
    }
    
    body {
        font-size: 12px;
        line-height: 1.2;
    }
    
    .btn, .badge {
        border: none;
        background: none;
        color: #000 !important;
        padding: 0;
    }
    
    .receipt-actions {
        display: none;
    }
    
    .receipt-footer {
        margin-top: 2rem;
        padding-top: 1rem;
        border-top: 1px solid #eee;
    }
}
</style>
